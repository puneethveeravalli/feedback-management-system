const express = require("express");
const {
  createAccessCredential,
  getAccessCredentials,
  getAccessCredentialById,
  revokeAccessCredential,
  validateAccessCredential,
} = require("../controllers/accessCredentialController");
const protect = require("../middleware/authMiddleware");
const authorize = require("../middleware/roleMiddleware");

const router = express.Router();

router.post("/", protect, authorize("SUPER_ADMIN", "ORG_ADMIN"), createAccessCredential);
router.get("/", protect, authorize("SUPER_ADMIN", "ORG_ADMIN", "MANAGER"), getAccessCredentials);
router.get("/:id", protect, authorize("SUPER_ADMIN", "ORG_ADMIN", "MANAGER"), getAccessCredentialById);
router.patch("/:id/revoke", protect, authorize("SUPER_ADMIN", "ORG_ADMIN"), revokeAccessCredential);
router.post("/validate", validateAccessCredential);

module.exports = router;
