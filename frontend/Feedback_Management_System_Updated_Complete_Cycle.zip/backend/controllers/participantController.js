const mongoose = require("mongoose");
const crypto = require("crypto");

const Participant = require("../models/Participant");
const User = require("../models/User");
const Group = require("../models/Group");
const Assignment = require("../models/Assignment");
const FeedbackForm = require("../models/FeedbackForm");
const Response = require("../models/Response");
const Question = require("../models/Question");
const AccessCredential = require("../models/AccessCredential");
const AccessSession = require("../models/AccessSession");
const Counter = require("../models/Counter");

const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id);
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const generatePassword = () => crypto.randomBytes(9).toString("base64url");
const generateSessionToken = () => crypto.randomBytes(32).toString("hex");
const hashToken = (token) => crypto.createHash("sha256").update(token).digest("hex");

const requireOrganization = (req, res) => {
  if (!req.organizationId) {
    res.status(400).json({
      success: false,
      message: "Select an organization before managing participants.",
    });
    return null;
  }
  return req.organizationId;
};

const getNextExternalId = async (organizationId) => {
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const counter = await Counter.findOneAndUpdate(
      { organizationId, key: "PARTICIPANT" },
      { $inc: { sequence: 1 } },
      { new: true, upsert: true, setDefaultsOnInsert: true }
    );

    const externalId = `P${String(counter.sequence).padStart(3, "0")}`;
    const exists = await Participant.exists({ organizationId, externalId });
    if (!exists) return externalId;
  }

  throw new Error("Unable to generate a unique participant External ID");
};

const validateParticipantInput = ({ name, email, groupId }) => {
  const errors = {};
  const cleanName = String(name || "").trim();
  const cleanEmail = String(email || "").trim().toLowerCase();

  if (!cleanName) errors.name = "Participant name is required.";
  else if (cleanName.length < 2) errors.name = "Participant name must contain at least 2 characters.";
  else if (cleanName.length > 150) errors.name = "Participant name cannot exceed 150 characters.";

  if (!cleanEmail) errors.email = "Email is required for participant login.";
  else if (!emailRegex.test(cleanEmail)) errors.email = "Enter a valid email address.";
  else if (cleanEmail.length > 150) errors.email = "Email cannot exceed 150 characters.";

  if (!groupId || !isValidObjectId(groupId)) errors.groupId = "A valid group is required.";

  return { errors, cleanName, cleanEmail };
};

const validateGroup = async (groupId, organizationId) => {
  const group = await Group.findOne({
    _id: groupId,
    organizationId,
    status: "ACTIVE",
  });
  return group;
};

const createParticipantRecord = async ({ organizationId, name, email, groupId }) => {
  const { errors, cleanName, cleanEmail } = validateParticipantInput({ name, email, groupId });
  if (Object.keys(errors).length) {
    const error = new Error(Object.values(errors)[0]);
    error.code = "VALIDATION";
    throw error;
  }

  const group = await validateGroup(groupId, organizationId);
  if (!group) {
    const error = new Error("Selected group is not available.");
    error.code = "GROUP";
    throw error;
  }

  const existingParticipant = await Participant.findOne({
    organizationId,
    email: cleanEmail,
  });
  if (existingParticipant) {
    const error = new Error("A participant with this email already exists.");
    error.code = "DUPLICATE";
    throw error;
  }

  const existingUser = await User.findOne({ email: cleanEmail });
  if (existingUser) {
    const error = new Error("A user account already exists with this email address.");
    error.code = "DUPLICATE";
    throw error;
  }

  const externalId = await getNextExternalId(organizationId);
  const password = generatePassword();

  const participant = await Participant.create({
    organizationId,
    groupId,
    name: cleanName,
    email: cleanEmail,
    externalId,
    status: "ACTIVE",
  });

  try {
    const user = await User.create({
      organizationId,
      participantId: participant._id,
      name: cleanName,
      email: cleanEmail,
      password,
      role: "PARTICIPANT",
      status: "ACTIVE",
    });

    const populated = await Participant.findById(participant._id).populate("groupId", "name status");

    return {
      participant: populated,
      credentials: {
        name: user.name,
        externalId,
        email: user.email,
        password,
      },
    };
  } catch (error) {
    await Participant.findByIdAndDelete(participant._id);
    throw error;
  }
};

const createParticipant = async (req, res) => {
  try {
    const organizationId = requireOrganization(req, res);
    if (!organizationId) return;

    const result = await createParticipantRecord({
      organizationId,
      name: req.body.name,
      email: req.body.email,
      groupId: req.body.groupId,
    });

    return res.status(201).json({
      success: true,
      message: "Participant and login account created successfully",
      ...result,
    });
  } catch (error) {
    console.error("Create participant error:", error);
    const status = ["VALIDATION", "GROUP"].includes(error.code)
      ? 400
      : error.code === "DUPLICATE"
      ? 409
      : 500;
    return res.status(status).json({ success: false, message: error.message || "Failed to create participant" });
  }
};

const bulkUploadParticipants = async (req, res) => {
  try {
    const organizationId = requireOrganization(req, res);
    if (!organizationId) return;

    const rows = Array.isArray(req.body.participants) ? req.body.participants : [];
    if (!rows.length) {
      return res.status(400).json({ success: false, message: "No participant records were provided." });
    }
    if (rows.length > 1000) {
      return res.status(400).json({ success: false, message: "A maximum of 1000 participants can be imported at once." });
    }

    const created = [];
    const failed = [];

    for (let index = 0; index < rows.length; index += 1) {
      const row = rows[index] || {};
      const rowNumber = index + 2;
      const groupValue = row.groupId || row.group || row.groupName || "";
      let groupId = groupValue;

      if (groupValue && !isValidObjectId(groupValue)) {
        const group = await Group.findOne({
          organizationId,
          name: new RegExp(`^${String(groupValue).trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, "i"),
        });
        groupId = group?._id;
      }

      try {
        const result = await createParticipantRecord({
          organizationId,
          name: row.name,
          email: row.email,
          groupId,
        });

        created.push({
          row: rowNumber,
          ...result.credentials,
        });
      } catch (error) {
        failed.push({
          row: rowNumber,
          name: row.name || "",
          email: row.email || "",
          message: error.message || "Unable to import participant",
        });
      }
    }

    return res.status(created.length ? 201 : 400).json({
      success: created.length > 0,
      message: `Import completed: ${created.length} created, ${failed.length} failed.`,
      summary: {
        total: rows.length,
        created: created.length,
        failed: failed.length,
      },
      created,
      failed,
    });
  } catch (error) {
    console.error("Bulk participant upload error:", error);
    return res.status(500).json({ success: false, message: "Failed to import participants." });
  }
};

const getParticipants = async (req, res) => {
  try {
    const filter = req.organizationId ? { organizationId: req.organizationId } : {};
    const participants = await Participant.find(filter)
      .populate("groupId", "name status")
      .sort({ createdAt: -1 });

    return res.status(200).json({ success: true, count: participants.length, participants });
  } catch (error) {
    console.error("Get participants error:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch participants" });
  }
};

const getParticipantById = async (req, res) => {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: "Invalid participant ID" });
    }
    const filter = req.organizationId
      ? { _id: req.params.id, organizationId: req.organizationId }
      : { _id: req.params.id };
    const participant = await Participant.findOne(filter).populate("groupId", "name status");
    if (!participant) return res.status(404).json({ success: false, message: "Participant not found" });
    return res.status(200).json({ success: true, participant });
  } catch (error) {
    console.error("Get participant error:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch participant" });
  }
};

const updateParticipant = async (req, res) => {
  try {
    const organizationId = requireOrganization(req, res);
    if (!organizationId) return;
    if (!isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: "Invalid participant ID" });

    const participant = await Participant.findOne({ _id: req.params.id, organizationId });
    if (!participant) return res.status(404).json({ success: false, message: "Participant not found" });

    const { errors, cleanName, cleanEmail } = validateParticipantInput({
      name: req.body.name,
      email: req.body.email,
      groupId: req.body.groupId,
    });
    if (Object.keys(errors).length) return res.status(400).json({ success: false, message: Object.values(errors)[0] });

    const group = await validateGroup(req.body.groupId, organizationId);
    if (!group) return res.status(400).json({ success: false, message: "Selected group is not available." });

    const duplicate = await Participant.findOne({
      organizationId,
      email: cleanEmail,
      _id: { $ne: participant._id },
    });
    if (duplicate) return res.status(409).json({ success: false, message: "Another participant already uses this email." });

    const linkedUser = await User.findOne({ participantId: participant._id, role: "PARTICIPANT" });
    const emailOwner = await User.findOne({ email: cleanEmail, _id: { $ne: linkedUser?._id } });
    if (emailOwner) return res.status(409).json({ success: false, message: "A user account already exists with this email address." });

    participant.name = cleanName;
    participant.email = cleanEmail;
    participant.groupId = req.body.groupId;
    await participant.save();

    if (linkedUser) {
      linkedUser.name = cleanName;
      linkedUser.email = cleanEmail;
      if (req.body.password) {
        if (req.body.password.length < 6) return res.status(400).json({ success: false, message: "Password must contain at least 6 characters." });
        linkedUser.password = req.body.password;
      }
      await linkedUser.save();
    }

    const updated = await Participant.findById(participant._id).populate("groupId", "name status");
    return res.status(200).json({ success: true, message: "Participant updated successfully", participant: updated });
  } catch (error) {
    console.error("Update participant error:", error);
    return res.status(500).json({ success: false, message: "Failed to update participant" });
  }
};

const updateParticipantStatus = async (req, res) => {
  try {
    const organizationId = requireOrganization(req, res);
    if (!organizationId) return;
    const { status } = req.body;
    if (!["ACTIVE", "INACTIVE"].includes(status)) return res.status(400).json({ success: false, message: "Invalid participant status" });

    const participant = await Participant.findOne({ _id: req.params.id, organizationId });
    if (!participant) return res.status(404).json({ success: false, message: "Participant not found" });

    participant.status = status;
    await participant.save();

    await User.updateOne(
      { participantId: participant._id, role: "PARTICIPANT" },
      { $set: { status } }
    );

    return res.status(200).json({ success: true, message: `Participant ${status === "ACTIVE" ? "activated" : "deactivated"} successfully`, participant });
  } catch (error) {
    console.error("Update participant status error:", error);
    return res.status(500).json({ success: false, message: "Failed to update participant status" });
  }
};

const getMyParticipant = async (req, res) => {
  try {
    const participant = await Participant.findOne({
      _id: req.user.participantId,
      organizationId: req.user.organizationId,
    }).populate("groupId", "name status");
    if (!participant) return res.status(404).json({ success: false, message: "Participant profile not found" });
    return res.status(200).json({ success: true, participant });
  } catch (error) {
    console.error("Get my participant error:", error);
    return res.status(500).json({ success: false, message: "Failed to load participant profile" });
  }
};

const getAvailableFeedback = async (req, res) => {
  try {
    if (req.user.role !== "PARTICIPANT" || !req.user.participantId) {
      return res.status(403).json({ success: false, message: "Participant access required" });
    }

    const participant = await Participant.findOne({
      _id: req.user.participantId,
      organizationId: req.user.organizationId,
      status: "ACTIVE",
    }).populate("groupId", "name status");

    if (!participant) return res.status(404).json({ success: false, message: "Participant profile not found" });
    if (!participant.groupId || participant.groupId.status !== "ACTIVE") {
      return res.status(403).json({ success: false, message: "Your group is currently inactive" });
    }

    const assignments = await Assignment.find({
      organizationId: req.user.organizationId,
      groupId: participant.groupId._id,
      status: "ACTIVE",
    })
      .populate("formId", "title description startDate endDate responseMode allowMultipleResponses confirmationMessage status")
      .sort({ createdAt: -1 });

    const now = new Date();
    const feedback = [];

    for (const assignment of assignments) {
      const form = assignment.formId;
      if (!form || !["PUBLISHED", "ACTIVE"].includes(form.status)) continue;
      if (form.startDate && now < new Date(form.startDate)) continue;
      if (form.endDate && now > new Date(form.endDate)) continue;

      let credential = await AccessCredential.findOne({
        organizationId: req.user.organizationId,
        assignmentId: assignment._id,
        participantId: participant._id,
        accessType: "LOGIN",
      }).select("_id status");

      if (!credential) {
        credential = await AccessCredential.create({
          organizationId: req.user.organizationId,
          assignmentId: assignment._id,
          scopeType: "PARTICIPANT",
          participantId: participant._id,
          accessType: "LOGIN",
          status: "ACTIVE",
        });
      }

      if (credential.status === "REVOKED" || credential.status === "EXPIRED") continue;

      if (!form.allowMultipleResponses) {
        const submitted = await Response.exists({
          organizationId: req.user.organizationId,
          assignmentId: assignment._id,
          credentialId: credential._id,
          status: "SUBMITTED",
        });
        if (submitted) continue;
      }

      feedback.push({
        assignmentId: assignment._id,
        formId: form._id,
        title: form.title,
        description: form.description || "",
        startDate: form.startDate,
        endDate: form.endDate,
        responseMode: form.responseMode,
        allowMultipleResponses: form.allowMultipleResponses,
        status: "AVAILABLE",
      });
    }

    return res.status(200).json({
      success: true,
      participant: {
        id: participant._id,
        name: participant.name,
        email: participant.email,
        externalId: participant.externalId,
        group: participant.groupId
          ? { id: participant.groupId._id, name: participant.groupId.name }
          : null,
      },
      feedback,
    });
  } catch (error) {
    console.error("Get available participant feedback error:", error);
    return res.status(500).json({ success: false, message: "Failed to load assigned feedback" });
  }
};

const startParticipantFeedback = async (req, res) => {
  try {
    if (req.user.role !== "PARTICIPANT" || !req.user.participantId) {
      return res.status(403).json({ success: false, message: "Participant access required" });
    }

    const { assignmentId } = req.body;
    if (!isValidObjectId(assignmentId)) return res.status(400).json({ success: false, message: "Invalid assignment ID" });

    const participant = await Participant.findOne({
      _id: req.user.participantId,
      organizationId: req.user.organizationId,
      status: "ACTIVE",
    });
    if (!participant) return res.status(404).json({ success: false, message: "Participant profile not found" });

    const assignment = await Assignment.findOne({
      _id: assignmentId,
      organizationId: req.user.organizationId,
      groupId: participant.groupId,
      status: "ACTIVE",
    }).populate("formId", "title description startDate endDate responseMode allowMultipleResponses confirmationMessage status");

    if (!assignment || !assignment.formId) return res.status(404).json({ success: false, message: "Assigned feedback form was not found" });

    const form = assignment.formId;
    if (!["PUBLISHED", "ACTIVE"].includes(form.status)) return res.status(403).json({ success: false, message: "Feedback form is not available" });

    const now = new Date();
    if (form.startDate && now < new Date(form.startDate)) return res.status(403).json({ success: false, message: "Feedback form has not started yet" });
    if (form.endDate && now > new Date(form.endDate)) return res.status(403).json({ success: false, message: "Feedback form has closed" });

    let credential = await AccessCredential.findOne({
      organizationId: req.user.organizationId,
      assignmentId: assignment._id,
      participantId: participant._id,
      accessType: "LOGIN",
    }).select("+password");

    if (!credential) {
      credential = await AccessCredential.create({
        organizationId: req.user.organizationId,
        assignmentId: assignment._id,
        scopeType: "PARTICIPANT",
        participantId: participant._id,
        accessType: "LOGIN",
        status: "ACTIVE",
      });
    }

    if (["REVOKED", "EXPIRED"].includes(credential.status)) {
      return res.status(403).json({ success: false, message: "Feedback access has been revoked or expired" });
    }

    if (!form.allowMultipleResponses) {
      const submitted = await Response.exists({
        organizationId: req.user.organizationId,
        assignmentId: assignment._id,
        credentialId: credential._id,
        status: "SUBMITTED",
      });
      if (submitted) return res.status(409).json({ success: false, message: "You have already submitted this feedback" });
    }

    const questions = await Question.find({
      organizationId: req.user.organizationId,
      formId: form._id,
      status: "ACTIVE",
    }).sort({ order: 1 }).select("_id questionText type options required order minValue maxValue");

    if (!questions.length) return res.status(400).json({ success: false, message: "This feedback form has no active questions" });

    const sessionToken = generateSessionToken();
    await AccessSession.create({
      organizationId: req.user.organizationId,
      credentialId: credential._id,
      participantId: participant._id,
      tokenHash: hashToken(sessionToken),
      expiresAt: new Date(Date.now() + 30 * 60 * 1000),
    });

    credential.lastUsedAt = new Date();
    await credential.save();

    return res.status(200).json({
      success: true,
      message: "Feedback access granted",
      access: {
        assignmentId: assignment._id,
        formId: form._id,
        accessType: "LOGIN",
        scopeType: "PARTICIPANT",
        sessionToken,
        participantId: form.responseMode === "ANONYMOUS" ? null : participant._id,
      },
      form: {
        id: form._id,
        title: form.title,
        description: form.description,
        responseMode: form.responseMode,
        allowMultipleResponses: form.allowMultipleResponses,
        confirmationMessage: form.confirmationMessage,
      },
      questions,
    });
  } catch (error) {
    console.error("Start participant feedback error:", error);
    return res.status(500).json({ success: false, message: "Failed to start feedback" });
  }
};

module.exports = {
  createParticipant,
  bulkUploadParticipants,
  getParticipants,
  getParticipantById,
  updateParticipant,
  updateParticipantStatus,
  getMyParticipant,
  getAvailableFeedback,
  startParticipantFeedback,
};
