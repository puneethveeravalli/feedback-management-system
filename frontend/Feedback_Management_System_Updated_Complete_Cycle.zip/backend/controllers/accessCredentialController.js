const crypto = require("crypto");
const mongoose = require("mongoose");

const AccessCredential = require("../models/AccessCredential");
const AccessSession = require("../models/AccessSession");
const Assignment = require("../models/Assignment");
const Participant = require("../models/Participant");
const FeedbackForm = require("../models/FeedbackForm");
const Question = require("../models/Question");
const Response = require("../models/Response");

const PUBLIC_ACCESS_TYPES = ["ACCESS_CODE", "UNIQUE_LINK", "QR"];
const ALL_ACCESS_TYPES = ["LOGIN", ...PUBLIC_ACCESS_TYPES];
const SCOPE_TYPES = ["GROUP", "PARTICIPANT"];

const hashToken = (token) => crypto.createHash("sha256").update(token).digest("hex");
const generateAccessCode = () => crypto.randomBytes(5).toString("hex").toUpperCase();
const generateToken = () => crypto.randomBytes(32).toString("hex");
const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id);
const getClientUrl = () => (process.env.CLIENT_URL || "http://localhost:5173").replace(/\/$/, "");

const requireOrganization = (req, res) => {
  if (!req.organizationId) {
    res.status(400).json({ success: false, message: "Select an organization before managing access." });
    return null;
  }
  return req.organizationId;
};

const parseExpiry = (value) => {
  if (!value) return { value: null };
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return { error: "Invalid expiry date" };
  if (date <= new Date()) return { error: "Expiry date must be in the future" };
  return { value: date };
};

const loadAssignment = async (assignmentId, organizationId) => {
  if (!isValidObjectId(assignmentId)) return null;
  return Assignment.findOne({ _id: assignmentId, organizationId })
    .populate("formId", "title status startDate endDate responseMode allowMultipleResponses confirmationMessage")
    .populate("groupId", "name status");
};

const validateAssignment = (assignment) => {
  if (!assignment) return "Assignment not found";
  if (assignment.status !== "ACTIVE") return "Cannot create access for an inactive assignment";
  if (!assignment.formId) return "The assignment does not have a valid feedback form";
  if (["CLOSED", "ARCHIVED"].includes(assignment.formId.status)) return "Cannot create access for a closed or archived form";
  if (!assignment.groupId || assignment.groupId.status !== "ACTIVE") return "The assignment group is inactive";
  return null;
};

const validateParticipant = async (participantId, assignment, organizationId) => {
  if (!isValidObjectId(participantId)) return { error: "Invalid participant ID" };
  const participant = await Participant.findOne({ _id: participantId, organizationId });
  if (!participant) return { error: "Participant not found" };
  if (participant.status !== "ACTIVE") return { error: "Participant is inactive" };
  if (!participant.groupId || participant.groupId.toString() !== assignment.groupId._id.toString()) {
    return { error: "Participant does not belong to the assignment group" };
  }
  return { participant };
};

const outputCredential = (credential, participant = null) => {
  let accessUrl;
  if (["UNIQUE_LINK", "QR"].includes(credential.accessType)) {
    accessUrl = `${getClientUrl()}/participant-access?token=${encodeURIComponent(credential.uniqueToken)}`;
  }
  return {
    id: credential._id,
    assignmentId: credential.assignmentId,
    participantId: credential.participantId || null,
    participantName: participant?.name || null,
    scopeType: credential.scopeType,
    accessType: credential.accessType,
    accessCode: credential.accessCode || undefined,
    accessUrl,
    expiresAt: credential.expiresAt,
    status: credential.status,
  };
};

const createAccessCredential = async (req, res) => {
  try {
    const organizationId = requireOrganization(req, res);
    if (!organizationId) return;

    const { assignmentId, scopeType = "GROUP", participantId, accessType, expiresAt } = req.body;
    if (!assignmentId || !accessType) return res.status(400).json({ success: false, message: "assignmentId and accessType are required" });
    if (!SCOPE_TYPES.includes(scopeType)) return res.status(400).json({ success: false, message: "scopeType must be GROUP or PARTICIPANT" });
    if (!PUBLIC_ACCESS_TYPES.includes(accessType)) return res.status(400).json({ success: false, message: `Access method must be one of: ${PUBLIC_ACCESS_TYPES.join(", ")}` });

    const expiry = parseExpiry(expiresAt);
    if (expiry.error) return res.status(400).json({ success: false, message: expiry.error });

    const assignment = await loadAssignment(assignmentId, organizationId);
    const assignmentError = validateAssignment(assignment);
    if (assignmentError) return res.status(400).json({ success: false, message: assignmentError });

    const form = assignment.formId;

    if (scopeType === "GROUP" && form.responseMode === "IDENTIFIED") {
      return res.status(400).json({ success: false, message: "Identified feedback requires individual participant access." });
    }

    if (scopeType === "GROUP" && form.responseMode === "ANONYMOUS" && !form.allowMultipleResponses) {
      return res.status(400).json({ success: false, message: "Anonymous one-response feedback requires individual participant access." });
    }

    let participant = null;
    if (scopeType === "PARTICIPANT") {
      if (!participantId) return res.status(400).json({ success: false, message: "participantId is required for individual access" });
      const result = await validateParticipant(participantId, assignment, organizationId);
      if (result.error) return res.status(400).json({ success: false, message: result.error });
      participant = result.participant;
    }

    const duplicateFilter = {
      organizationId,
      assignmentId,
      scopeType,
      accessType,
      participantId: participant?._id || null,
      status: "ACTIVE",
    };
    const existing = await AccessCredential.findOne(duplicateFilter);
    if (existing) return res.status(409).json({ success: false, message: "An active access credential already exists for this selection" });

    const accessCode = accessType === "ACCESS_CODE" ? generateAccessCode() : "";
    const uniqueToken = ["UNIQUE_LINK", "QR"].includes(accessType) ? generateToken() : "";

    const credential = await AccessCredential.create({
      organizationId,
      assignmentId,
      scopeType,
      participantId: participant?._id || null,
      accessType,
      accessCode,
      uniqueToken,
      status: "ACTIVE",
      expiresAt: expiry.value,
    });

    return res.status(201).json({
      success: true,
      message: "Access credential created successfully",
      credential: outputCredential(credential, participant),
      credentials: [outputCredential(credential, participant)],
      count: 1,
    });
  } catch (error) {
    console.error("Create access credential error:", error);
    return res.status(500).json({ success: false, message: "Failed to create access credential" });
  }
};

const getAccessCredentials = async (req, res) => {
  try {
    const filter = req.organizationId
      ? { organizationId: req.organizationId, accessType: { $in: PUBLIC_ACCESS_TYPES } }
      : { accessType: { $in: PUBLIC_ACCESS_TYPES } };

    const credentials = await AccessCredential.find(filter)
      .select("+accessCode +uniqueToken")
      .populate({
        path: "assignmentId",
        populate: [
          { path: "formId", select: "title status responseMode" },
          { path: "groupId", select: "name status" },
        ],
      })
      .populate("participantId", "name email externalId")
      .sort({ createdAt: -1 });

    const safeCredentials = credentials.map((credential) => ({
      ...credential.toObject(),
      accessUrl: ["UNIQUE_LINK", "QR"].includes(credential.accessType)
        ? `${getClientUrl()}/participant-access?token=${encodeURIComponent(credential.uniqueToken)}`
        : undefined,
      uniqueToken: undefined,
    }));

    return res.status(200).json({ success: true, credentials: safeCredentials });
  } catch (error) {
    console.error("Get access credentials error:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch access credentials" });
  }
};

const getAccessCredentialById = async (req, res) => {
  try {
    const filter = req.organizationId
      ? { _id: req.params.id, organizationId: req.organizationId }
      : { _id: req.params.id };
    const credential = await AccessCredential.findOne(filter)
      .populate({
        path: "assignmentId",
        populate: [
          { path: "formId", select: "title status responseMode" },
          { path: "groupId", select: "name status" },
        ],
      })
      .populate("participantId", "name email externalId");
    if (!credential) return res.status(404).json({ success: false, message: "Access credential not found" });
    return res.status(200).json({ success: true, credential });
  } catch (error) {
    console.error("Get access credential error:", error);
    return res.status(500).json({ success: false, message: "Failed to fetch access credential" });
  }
};

const revokeAccessCredential = async (req, res) => {
  try {
    const organizationId = requireOrganization(req, res);
    if (!organizationId) return;
    const credential = await AccessCredential.findOne({ _id: req.params.id, organizationId });
    if (!credential) return res.status(404).json({ success: false, message: "Access credential not found" });
    credential.status = "REVOKED";
    await credential.save();
    await AccessSession.deleteMany({ credentialId: credential._id });
    return res.status(200).json({ success: true, message: "Access credential revoked successfully" });
  } catch (error) {
    console.error("Revoke access credential error:", error);
    return res.status(500).json({ success: false, message: "Failed to revoke access credential" });
  }
};

const resolvePublicCredential = async ({ accessCode, uniqueToken }) => {
  if (accessCode) {
    return AccessCredential.findOne({
      accessCode: accessCode.trim().toUpperCase(),
      status: "ACTIVE",
      accessType: "ACCESS_CODE",
    }).select("+accessCode +uniqueToken").populate("assignmentId").populate("participantId");
  }

  if (uniqueToken) {
    return AccessCredential.findOne({
      uniqueToken,
      status: "ACTIVE",
      accessType: { $in: ["UNIQUE_LINK", "QR"] },
    }).select("+uniqueToken").populate("assignmentId").populate("participantId");
  }

  return null;
};

const validateAccessCredential = async (req, res) => {
  try {
    const { accessCode, uniqueToken } = req.body;
    if (!accessCode && !uniqueToken) {
      return res.status(400).json({ message: "Provide an access code or secure link" });
    }

    const credential = await resolvePublicCredential({ accessCode, uniqueToken });
    if (!credential) return res.status(401).json({ message: "Invalid or expired access credential" });

    if (credential.expiresAt && new Date() > new Date(credential.expiresAt)) {
      credential.status = "EXPIRED";
      await credential.save();
      return res.status(401).json({ message: "Access credential has expired" });
    }

    const assignment = credential.assignmentId;
    if (!assignment || assignment.status !== "ACTIVE") return res.status(403).json({ message: "Assignment is not active" });

    const form = await FeedbackForm.findOne({ _id: assignment.formId, organizationId: credential.organizationId });
    if (!form) return res.status(404).json({ message: "Feedback form not found" });
    if (!["PUBLISHED", "ACTIVE"].includes(form.status)) return res.status(403).json({ message: "Feedback form is not available" });

    const now = new Date();
    if (form.startDate && now < new Date(form.startDate)) return res.status(403).json({ message: "Feedback form has not started yet" });
    if (form.endDate && now > new Date(form.endDate)) return res.status(403).json({ message: "Feedback form has closed" });

    const participant = credential.participantId;
    if (participant) {
      if (participant.status !== "ACTIVE") return res.status(403).json({ message: "Participant is inactive" });
      if (!participant.groupId || participant.groupId.toString() !== assignment.groupId.toString()) {
        return res.status(403).json({ message: "Participant is not eligible for this assignment" });
      }
    }

    const questions = await Question.find({
      organizationId: credential.organizationId,
      formId: form._id,
      status: "ACTIVE",
    }).sort({ order: 1 }).select("_id questionText type options required order minValue maxValue");

    if (!questions.length) return res.status(400).json({ message: "This feedback form has no active questions" });

    if (!form.allowMultipleResponses) {
      const existing = await Response.findOne({ credentialId: credential._id, status: "SUBMITTED" });
      if (existing) return res.status(409).json({ message: "You have already submitted this feedback" });
    }

    const sessionToken = generateToken();
    await AccessSession.create({
      organizationId: credential.organizationId,
      credentialId: credential._id,
      participantId: participant?._id || null,
      tokenHash: hashToken(sessionToken),
      expiresAt: new Date(Date.now() + 30 * 60 * 1000),
    });

    credential.lastUsedAt = new Date();
    await credential.save();

    return res.status(200).json({
      success: true,
      message: "Access granted",
      access: {
        assignmentId: assignment._id,
        formId: form._id,
        accessType: credential.accessType,
        scopeType: credential.scopeType,
        sessionToken,
        participantId: form.responseMode === "ANONYMOUS" ? null : participant?._id || null,
      },
      form: {
        id: form._id,
        title: form.title,
        description: form.description,
        responseMode: form.responseMode,
        allowMultipleResponses: form.allowMultipleResponses,
        confirmationMessage: form.confirmationMessage,
      },
      questions,
    });
  } catch (error) {
    console.error("Validate access credential error:", error);
    return res.status(500).json({ message: "Failed to validate access" });
  }
};

module.exports = {
  createAccessCredential,
  getAccessCredentials,
  getAccessCredentialById,
  revokeAccessCredential,
  validateAccessCredential,
  ALL_ACCESS_TYPES,
};
