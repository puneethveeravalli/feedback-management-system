import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";
import Button from "../components/ui/Button";
import Loading from "../components/ui/Loading";
import EmptyState from "../components/ui/EmptyState";

const ParticipantAccess = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user } = useAuth();

  const [accessCode, setAccessCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [assignedFeedback, setAssignedFeedback] = useState([]);
  const [assignedLoading, setAssignedLoading] = useState(false);
  const [startingId, setStartingId] = useState(null);

  const validatePublicAccess = async (payload) => {
    try {
      setLoading(true);
      setError("");
      const response = await api.post("/access-credentials/validate", payload);
      sessionStorage.setItem("feedbackAccess", JSON.stringify(response.data));
      navigate("/take-feedback", { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || "Unable to validate access.");
    } finally {
      setLoading(false);
    }
  };

  const loadAssignedFeedback = async () => {
    try {
      setAssignedLoading(true);
      setError("");
      const response = await api.get("/participants/me/available-feedback");
      const list = response.data?.feedback || [];
      setAssignedFeedback(list);
    } catch (err) {
      setError(err.response?.data?.message || "Unable to load assigned feedback.");
    } finally {
      setAssignedLoading(false);
    }
  };

  useEffect(() => {
    const token = searchParams.get("token");
    if (token) {
      validatePublicAccess({ uniqueToken: token });
      return;
    }
    if (user?.role === "PARTICIPANT") loadAssignedFeedback();
  }, [user?.role, searchParams]);

  const startFeedback = async (assignmentId) => {
    try {
      setStartingId(assignmentId);
      setError("");
      const response = await api.post("/participants/me/start-feedback", { assignmentId });
      sessionStorage.setItem("feedbackAccess", JSON.stringify(response.data));
      navigate("/take-feedback", { replace: true });
    } catch (err) {
      setError(err.response?.data?.message || "Unable to open feedback.");
      await loadAssignedFeedback();
    } finally {
      setStartingId(null);
    }
  };

  const handleAccessCode = async (event) => {
    event.preventDefault();
    if (!accessCode.trim()) {
      setError("Please enter the access code.");
      return;
    }
    await validatePublicAccess({ accessCode: accessCode.trim().toUpperCase() });
  };

  const hasToken = Boolean(searchParams.get("token"));

  if (user?.role === "PARTICIPANT" && !hasToken) {
    return (
      <div className="participant-access-page">
        <div className="participant-access-card participant-assigned-card">
          <div className="participant-access-brand">
            <div className="participant-access-brand-mark">F</div>
            <span>Feedback Management</span>
          </div>

          <div className="participant-access-header">
            <h1>Your Assigned Feedback</h1>
            <p>Open an assigned feedback form to continue.</p>
          </div>

          {error && <div className="participant-access-error">{error}</div>}

          {assignedLoading ? (
            <Loading />
          ) : assignedFeedback.length === 0 ? (
            <EmptyState
              title="No feedback available"
              description="There are currently no active feedback forms assigned to you."
            />
          ) : (
            <div className="participant-assigned-list">
              {assignedFeedback.map((item) => (
                <div className="participant-assigned-item" key={item.assignmentId}>
                  <div>
                    <h3>{item.title}</h3>
                    {item.description && <p>{item.description}</p>}
                    <small>
                      {item.responseMode === "ANONYMOUS" ? "Anonymous" : "Identified"}
                      {item.endDate ? ` · Due ${new Date(item.endDate).toLocaleDateString("en-IN")}` : ""}
                    </small>
                  </div>
                  <Button
                    onClick={() => startFeedback(item.assignmentId)}
                    disabled={startingId === item.assignmentId}
                  >
                    {startingId === item.assignmentId ? "Opening..." : "Open Feedback"}
                  </Button>
                </div>
              ))}
            </div>
          )}

          <button className="participant-access-secondary-button" onClick={() => window.location.reload()}>
            Refresh assignments
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="participant-access-page">
      <div className="participant-access-card">
        <div className="participant-access-brand">
          <div className="participant-access-brand-mark">F</div>
          <span>Feedback Management</span>
        </div>

        <div className="participant-access-header">
          <h1>{hasToken ? "Verifying Access" : "Give Your Feedback"}</h1>
          <p>{hasToken ? "Please wait while we securely validate your link." : "Enter the access code shared with you."}</p>
        </div>

        {error && <div className="participant-access-error">{error}</div>}

        {hasToken ? (
          <Loading />
        ) : (
          <form className="participant-access-form" onSubmit={handleAccessCode}>
            <div className="participant-access-field">
              <label htmlFor="accessCode">Access Code</label>
              <input
                id="accessCode"
                value={accessCode}
                onChange={(event) => setAccessCode(event.target.value)}
                placeholder="Enter access code"
                autoComplete="off"
              />
            </div>
            <Button type="submit" disabled={loading}>
              {loading ? "Verifying..." : "Continue"}
            </Button>
          </form>
        )}

        <div className="participant-access-security">
          Access is validated securely before the feedback form opens.
        </div>
      </div>
    </div>
  );
};

export default ParticipantAccess;
