import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";

const Login = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const openParticipantFeedback = async () => {
    const availableResponse = await api.get("/participants/me/available-feedback");
    const feedback = availableResponse.data?.feedback || [];

    if (feedback.length === 1) {
      const startResponse = await api.post("/participants/me/start-feedback", {
        assignmentId: feedback[0].assignmentId,
      });
      sessionStorage.setItem("feedbackAccess", JSON.stringify(startResponse.data));
      navigate("/take-feedback", { replace: true });
      return;
    }

    navigate("/participant-access?mode=assigned", { replace: true });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setLoading(true);

    try {
      const data = await login(email.trim(), password);
      if (data.user.role === "PARTICIPANT") {
        try {
          await openParticipantFeedback();
        } catch (err) {
          setError(
            err.response?.data?.message ||
              "You are logged in, but no feedback could be opened right now."
          );
          navigate("/participant-access?mode=assigned", { replace: true });
        }
      } else {
        navigate("/dashboard", { replace: true });
      }
    } catch (err) {
      setError(err.response?.data?.message || "Invalid email or password");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-brand">
          <div className="brand-mark">F</div>
          <div>
            <h1>Feedback Management</h1>
            <span>System</span>
          </div>
        </div>

        <div className="login-heading">
          <h2>Welcome back</h2>
          <p>Sign in to continue to your account.</p>
        </div>

        {error && <div className="login-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="login-field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="Enter your email"
              autoComplete="email"
              required
            />
          </div>

          <div className="login-field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="Enter your password"
              autoComplete="current-password"
              required
            />
          </div>

          <button className="login-button" type="submit" disabled={loading}>
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </form>

        <div className="login-footer">
          <span>Secure Feedback Management System</span>
        </div>
      </div>
    </div>
  );
};

export default Login;
