import { useEffect, useMemo, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import api from "../services/api";
import Button from "../components/ui/Button";
import Select from "../components/ui/Select";
import Modal from "../components/ui/Modal";
import Badge from "../components/ui/Badge";
import Loading from "../components/ui/Loading";
import EmptyState from "../components/ui/EmptyState";

const ACCESS_TYPES = [
  { value: "ACCESS_CODE", label: "Access Code" },
  { value: "UNIQUE_LINK", label: "Unique Link" },
  { value: "QR", label: "QR Code" },
];

const INITIAL_FORM = {
  assignmentId: "",
  scopeType: "GROUP",
  participantId: "",
  accessType: "ACCESS_CODE",
  expiresAt: "",
};

const AccessCredentials = () => {
  const [credentials, setCredentials] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [participants, setParticipants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [generatedOpen, setGeneratedOpen] = useState(false);
  const [generated, setGenerated] = useState(null);
  const [formData, setFormData] = useState(INITIAL_FORM);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [credentialResponse, assignmentResponse, participantResponse] = await Promise.all([
        api.get("/access-credentials"),
        api.get("/assignments"),
        api.get("/participants"),
      ]);
      setCredentials(credentialResponse.data?.credentials || []);
      setAssignments(assignmentResponse.data?.assignments || []);
      setParticipants(participantResponse.data?.participants || []);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load access credentials.");
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const selectedAssignment = useMemo(() => assignments.find((item) => item._id === formData.assignmentId), [assignments, formData.assignmentId]);

  const eligibleParticipants = useMemo(() => {
    const groupId = selectedAssignment?.groupId?._id || selectedAssignment?.groupId;
    return participants.filter((participant) =>
      participant.status === "ACTIVE" && (participant.groupId?._id || participant.groupId) === groupId
    );
  }, [participants, selectedAssignment]);

  const getAssignment = (credential) => {
    const id = credential.assignmentId?._id || credential.assignmentId;
    return assignments.find((item) => item._id === id) || credential.assignmentId;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setSuccess("");

    if (!formData.assignmentId) return setError("Please select an assignment.");
    if (formData.scopeType === "PARTICIPANT" && !formData.participantId) return setError("Please select a participant.");

    const responseMode = selectedAssignment?.formId?.responseMode;
    const allowMultiple = selectedAssignment?.formId?.allowMultipleResponses;
    if (formData.scopeType === "GROUP" && responseMode === "IDENTIFIED") {
      return setError("Identified feedback requires individual participant access.");
    }
    if (formData.scopeType === "GROUP" && responseMode === "ANONYMOUS" && allowMultiple === false) {
      return setError("Anonymous one-response feedback requires individual participant access.");
    }

    try {
      setSaving(true);
      const payload = {
        assignmentId: formData.assignmentId,
        scopeType: formData.scopeType,
        accessType: formData.accessType,
      };
      if (formData.scopeType === "PARTICIPANT") payload.participantId = formData.participantId;
      if (formData.expiresAt) payload.expiresAt = new Date(formData.expiresAt).toISOString();

      const response = await api.post("/access-credentials", payload);
      setGenerated(response.data?.credentials || []);
      setGeneratedOpen(true);
      setModalOpen(false);
      setSuccess(response.data?.message || "Access created successfully.");
      setFormData(INITIAL_FORM);
      await fetchData();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to create access.");
    } finally { setSaving(false); }
  };

  const revoke = async (credential) => {
    if (!window.confirm("Revoke this access credential?")) return;
    try {
      await api.patch(`/access-credentials/${credential._id}/revoke`);
      setSuccess("Access credential revoked successfully.");
      await fetchData();
    } catch (err) { setError(err.response?.data?.message || "Failed to revoke access credential."); }
  };

  const copy = async (value) => {
    try { await navigator.clipboard.writeText(value); setSuccess("Copied to clipboard."); }
    catch { window.prompt("Copy this value:", value); }
  };

  const assignmentLabel = (assignment) => `${assignment.formId?.title || "Feedback Form"} — ${assignment.groupId?.name || "Group"}`;

  return (
    <div className="page">
      <div className="page-head">
        <div><h1>Access Credentials</h1><p>Configure group or individual access for assigned feedback.</p></div>
        <Button onClick={() => { setError(""); setModalOpen(true); }}>+ Configure Access</Button>
      </div>
      {error && <div className="error-box">{error}</div>}
      {success && <div className="success-box">{success}</div>}

      {loading ? <Loading /> : credentials.length === 0 ? (
        <EmptyState title="No access configured" description="Configure an access code, link or QR for an active assignment." action={<Button onClick={() => setModalOpen(true)}>Configure Access</Button>} />
      ) : (
        <div className="table-card"><div className="table-wrap"><table>
          <thead><tr><th>Feedback Form</th><th>Group</th><th>Scope</th><th>Method</th><th>Access</th><th>Status</th><th>Expires</th><th>Actions</th></tr></thead>
          <tbody>{credentials.map((credential) => {
            const assignment = getAssignment(credential);
            return <tr key={credential._id}>
              <td><strong>{assignment?.formId?.title || "—"}</strong></td>
              <td>{assignment?.groupId?.name || "—"}</td>
              <td>{credential.scopeType === "GROUP" ? "Entire Group" : `Individual — ${credential.participantId?.name || "Participant"}`}</td>
              <td>{credential.accessType === "ACCESS_CODE" ? "Access Code" : credential.accessType === "UNIQUE_LINK" ? "Unique Link" : "QR Code"}</td>
              <td>{credential.accessCode ? <Button size="sm" variant="secondary" onClick={() => copy(credential.accessCode)}>Copy Code</Button> : credential.accessUrl ? <Button size="sm" variant="secondary" onClick={() => copy(credential.accessUrl)}>Copy Link</Button> : "—"}</td>
              <td><Badge status={credential.status} /></td>
              <td>{credential.expiresAt ? new Date(credential.expiresAt).toLocaleString("en-IN") : "No expiry"}</td>
              <td>{credential.status === "ACTIVE" && <Button size="sm" variant="danger" onClick={() => revoke(credential)}>Revoke</Button>}</td>
            </tr>;
          })}</tbody>
        </table></div></div>
      )}

      <Modal open={modalOpen} title="Configure Feedback Access" onClose={() => !saving && setModalOpen(false)} footer={<><Button variant="secondary" onClick={() => setModalOpen(false)} disabled={saving}>Cancel</Button><Button type="submit" form="access-form" disabled={saving}>{saving ? "Creating..." : "Create Access"}</Button></>}>
        <form id="access-form" onSubmit={handleSubmit}>
          <Select label="Assignment" value={formData.assignmentId} onChange={(e) => setFormData({ ...formData, assignmentId: e.target.value, participantId: "" })} required>
            <option value="">Select assignment</option>
            {assignments.filter((assignment) => assignment.status === "ACTIVE").map((assignment) => <option key={assignment._id} value={assignment._id}>{assignmentLabel(assignment)}</option>)}
          </Select>
          <Select label="Access Scope" value={formData.scopeType} onChange={(e) => setFormData({ ...formData, scopeType: e.target.value, participantId: "" })} required>
            <option value="GROUP">Entire Group</option>
            <option value="PARTICIPANT">Individual Participant</option>
          </Select>
          {formData.scopeType === "PARTICIPANT" && <Select label="Participant" value={formData.participantId} onChange={(e) => setFormData({ ...formData, participantId: e.target.value })} required><option value="">Select participant</option>{eligibleParticipants.map((p) => <option key={p._id} value={p._id}>{p.name} — {p.email}</option>)}</Select>}
          <Select label="Access Method" value={formData.accessType} onChange={(e) => setFormData({ ...formData, accessType: e.target.value })} required>{ACCESS_TYPES.map((type) => <option key={type.value} value={type.value}>{type.label}</option>)}</Select>
          <div className="form-field"><label htmlFor="expiresAt">Expiry Date & Time</label><input id="expiresAt" type="datetime-local" value={formData.expiresAt} onChange={(e) => setFormData({ ...formData, expiresAt: e.target.value })} /></div>
          <div className="info-box"><strong>Participant login is separate.</strong><p>Participants created by the admin use their generated account credentials. These access credentials are for shared/group or individual code/link/QR access.</p></div>
        </form>
      </Modal>

      <Modal open={generatedOpen} title="Access Created" onClose={() => setGeneratedOpen(false)} footer={<Button onClick={() => setGeneratedOpen(false)}>Done</Button>}>
        {(generated || []).map((item) => <div className="credential-result" key={item.id}>
          {item.accessCode && <p><strong>Access Code:</strong> <code>{item.accessCode}</code> <Button size="sm" variant="secondary" onClick={() => copy(item.accessCode)}>Copy</Button></p>}
          {item.accessUrl && <><p><strong>Link:</strong> <code className="break-anywhere">{item.accessUrl}</code></p><Button size="sm" variant="secondary" onClick={() => copy(item.accessUrl)}>Copy Link</Button>{item.accessType === "QR" && <div className="access-qr-preview"><QRCodeSVG value={item.accessUrl} size={220} level="H" /></div>}</>}
        </div>)}
      </Modal>
    </div>
  );
};

export default AccessCredentials;
